    //Show top 10 news
fetch('https://gnews.io/api/v4/top-headlines?lang=en&token=6f85bd3002ee7dbddbf757d68e00d278')
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {
        console.log(data.articles);
        var articles = data.articles;
        let str = '';
        for (let i = 0; i < articles.length; i++) {

            str += "<div class='container'><div class='headline'><a href='" + articles[i].url + "' target='_blank'>" + articles[i].title + "</a></div></div>";
            str += "<div class='container'><div class='description'>" + articles[i].description + "</div></div>";
            str += "<div class='container'><div class='description'>" + articles[i].publishedAt + "</div></div>";
            str += "<div class='container'><div class='img'><img width='100%' src='" + articles[i].image + "'></div></div></div>";

        }

        document.getElementById("news").innerHTML = str;
    });

    //Search
var btnSearch = document.getElementById('btnSearch');

    //Return the search result

btnSearch.addEventListener('click', function() {
    var search = document.getElementById('search').value;

    fetch('https://gnews.io/api/v4/search?q=' + search + '&token=6f85bd3002ee7dbddbf757d68e00d278')
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            console.log(data.articles);
            var articles = data.articles;
            let str = '';
            for (let i = 0; i < articles.length; i++) {

                str += "<div class='container'><div class='headline'><a href='" + articles[i].url + "' target='_blank'>" + articles[i].title + "</a></div></div>";
                str += "<div class='container'><div class='description'>" + articles[i].description + "</div></div>";
                str += "<div class='container'><div class='description'>" + articles[i].publishedAt + "</div></div>";
                str += "<div class='container'><div class='img'><img width='100%' src='" + articles[i].image + "'></div></div>";

            }

            document.getElementById("news").innerHTML = str;
        });
});



 