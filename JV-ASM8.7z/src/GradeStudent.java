import java.util.Scanner;

public class GradeStudent {
    public static void main(String[] args) {
        Begin();
        MidTerm();
        Final();
        HomeWork();
        report();
    }

    public static void Begin() {
        System.out.println("This program reads exam/homework scores and reports your overall course grade");
        System.out.println("-----------------------------------------------------------------------------");
    }

     //Khai báo các phương thưc (biến) dùng chung
    public static int midWeight;
    public static int finalWeight;
    public static int homeWeight;
    public static double midAvg;
    public static double finalAvg;
    public static double homeAvg;

    // Điểm giữa kỳ
    public static void MidTerm() {
        System.out.println("Midterm:");
        System.out.println("Weight (0-100)? ");
        Scanner sc = new Scanner(System.in);
        midWeight = sc.nextInt();
        System.out.println("Score earned? ");
        int midScore = sc.nextInt();
        System.out.println("Were scores shifted (1 = yes, 2=no)? ");
        int midChange = sc.nextInt();
        int midShiftAmount;
        midShiftAmount = 0;
        if (midChange == 1) {
            System.out.println("Shift amount? ");
            midShiftAmount = sc.nextInt();
        }

        int midTotal;
        int midMax = 100;
        if ((midScore + midShiftAmount) > 100) {
            midTotal = midMax;
        } else {
            midTotal = (midScore + midShiftAmount);
        }
        midAvg = (double) midTotal / midMax * midWeight;
        midAvg = Math.round(midAvg * 10.0) / 10.0;
        System.out.println(midTotal + "/ 100");
        System.out.println("Weighted score = " + midAvg + "/" + midWeight);
    }

    // Điểm cuối kỳ
    public static void Final() {
        System.out.println("-----------------------------------------------------------------------------");
        System.out.println("Final:");
        System.out.println("Weight (0-100)? ");
        Scanner sc = new Scanner(System.in);
        finalWeight = sc.nextInt();
        System.out.println("Score earned? ");
        int finalScore = sc.nextInt();
        System.out.println("Were scores shifted (1 = yes, 2=no)? ");
        int finalChange = sc.nextInt();
        int finalShiftAmount;
        finalShiftAmount = 0;
        if (finalChange == 1) {
            System.out.println("Shift amount? ");
            finalShiftAmount = sc.nextInt();
        }
        int finalTotal;
        int finalMax = 100;
        if ((finalScore + finalShiftAmount) > 100) {
            finalTotal = finalMax;
        } else {
            finalTotal = finalScore + finalShiftAmount;
        }
        finalAvg = (double) finalTotal / finalMax * finalWeight;
        finalAvg = Math.round(finalAvg * 10.0) / 10.0;
        System.out.println(finalTotal + "/ 100");
        System.out.println("Weighted score = " + finalAvg + " /" + finalWeight);
    }

    // Bài tập về nhà
    public static void HomeWork() {
        System.out.println("-----------------------------------------------------------------------------");
        System.out.println("Homework:");
        System.out.println("Weight (0-100)? "); //3 weight = 100 điểm
        Scanner sc = new Scanner(System.in);
        // Tổng điểm trọng số: trọng số của 3 phần điểm thi phải có tổng chính xác là 100. Nhỏ hơn hoặc lớn hơn 100 đều không được
        do {
            homeWeight = sc.nextInt();
            if ((midWeight + finalWeight + homeWeight) != 100) {
                System.out.println("The total weight of 3 subjects is must equal 100");
            } else {
                break;
            }
        } while (midWeight + finalWeight + homeWeight != 100);

        //nhập bài ASM
        System.out.println("Number of assignments? ");
        int homeAsm = sc.nextInt();
        int i;
        int homeAsmSocre;
        int homeMax;
        int sumScore=0;
        int sumMax=0;
        for (i = 1; i <= homeAsm; i++) {
            System.out.println("Assignment " + i + " score and max? ");
            homeAsmSocre = sc.nextInt();
            sumScore +=homeAsmSocre;
            homeMax = sc.nextInt();
            sumMax += homeMax;
        }

        System.out.println("How many sections did you attend? ");
        int homeAttend = sc.nextInt();

        // Điểm tối đa của phần Attend là 30, nếu vượt quá 30 thì vẫn chỉ tính là 30.
        int homePoint;
        int homePointMax = 30;
        if (homeAttend > 6) {
            homePoint = homePointMax;
        } else {
            homePoint = homeAttend * 5;
        }
        System.out.println("Section points = " + homePoint + " /" + homePointMax);

        int homeTotal = 0;
        // Điểm tối đa của phần Assignment là 150, nếu vượt quá thì cũng chỉ tính là 150 điểm.
        homeMax = sumMax + homePointMax;
        if (homeMax >= 151){
            homeMax = 150;
        }else {
            homeMax = sumMax + homePointMax;
        }

        //Tổng điểm = các bài ASM + attend
        homeTotal = sumScore + homePoint;

        if (homeTotal > homeMax) {
            homeTotal = homeMax;
        }else {
            homeTotal = sumScore + homePoint;
        }

        homeAvg = (double)homeTotal/homeMax * homeWeight;
        homeAvg = Math.round(homeAvg * 10.0)/10.0;
        System.out.println("Total point " + homeTotal + "/ "+ homeMax);
        System.out.println("Weighted score = " + homeAvg + " /" + homeWeight);
    }

    // Report
    public static double report() {
        System.out.println("-----------------------------------------------------------------------------");
        double overall = midAvg + finalAvg + homeAvg;
        overall = Math.round(overall * 10.0) / 10.0;
        System.out.println("Overall percentage = " + overall);
        double minGrade;
        if (overall >= 85.0) {
            minGrade = 3;
        } else if (overall >= 75 && overall < 85) {
            minGrade = 2;
        } else if (overall >= 60 && overall < 75) {
            minGrade = 0.7;
        } else {
            minGrade = 0;
        }
        System.out.println("Your grade will be at least: " + minGrade);
        System.out.println("-----------------------------------------------------------------------------");
        /**Comment**/
        if (minGrade == 3) {
            System.out.println("You have completed the course excellently! ^^");
        } else if (minGrade == 2) {
            System.out.println("You did a good job! :))");
        } else if (minGrade == 0.7) {
            System.out.println("You need to try harder! :(");
        } else {
            System.out.println("Wish you luck next time!");
        }
        System.out.println("******************************************************************************");
        return overall;

    }

}
