import java.text.DecimalFormat;
import java.util.Comparator;

public class Employee extends Staff{
    // Thuoc tinh
    private float salary;
    private double overtimeHour;

    // Phuong thuc khoi tao
    public Employee() {

    }
    public Employee(String id, String name, int age, double payRate, String startDate, String deptId, int numDayOff, float salary, double overtimeHour){
        super(id, name, age, payRate, startDate, deptId, numDayOff);
        this.salary = salary;
        this.overtimeHour = overtimeHour;
    }
    
    public float getSalary(){
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    // Phuong thuc khac, hiển thị thông tin nhân viên
    @Override
    public void displayInformation(){
        System.out.println(String.format("%-15s%-30s%-10s%-10s%-12s%-15s%-10s%-1s",
                "|ID: " + super.getId(),
                "| Employee Name: " + super.getName(),
                "| Age: " + super.getAge(),
                "| Pay Rate: " + super.getPayRate(),
                "| Start Date: " + super.getStartDate(),
                "| DeptID: " + super.getDeptId(),
                "| Number Day Off: " + super.getNumDayOff(),
                " |"));
    }
    //Tình lương nhân viên
    @Override
    public float calculatorSalary() {
        return (float) (getPayRate() * 3000000 + overtimeHour * 200000);
    }

    @Override
    public void displaySalary(){
        DecimalFormat df = new DecimalFormat("0.00");
        System.out.println(String.format("|%-15s%-10s|","ID: " + super.getId() ,"Salary: " + df.format(salary)));
    }

}
