import java.util.*;
import java.util.Collections;

public class HumanResources {
    // Danh sach nhan vien (luu ca Employee va Manager)
    static ArrayList<Staff> staffList = new ArrayList<>();

    // Danh sach bo phan
    static ArrayList<Department> deptList = new ArrayList<>();

    public static void main(String[] args) {
        initData();

        Scanner input = new Scanner(System.in);
        int luaChon = 0;
        do {
            System.out.println("------------------------------------------------------------");
            System.out.println("1. Hiển thị danh sách nhân viên hiện có trong công ty ");
            System.out.println("2. Hiển thị các bộ phận trong công ty ");
            System.out.println("3. Hiển thị các nhân viên theo từng bộ phận ");
            System.out.println("4. Thêm nhân viên mới vào công ty ");
            System.out.println("5. Tìm kiếm thông tin nhân viên theo tên hoặc mã nhân viên");
            System.out.println("6. Hiển thị bảng lương của nhân viên toàn công ty ");
            System.out.println("7. Hiển thị bảng lương của nhân viên theo thứ tự tăng dần ");
            System.out.println("8. Hiển thị bảng lương của nhân viên theo thứ tự giảm dần ");
            System.out.println("9. Thoat");
            System.out.println("------------------------------------------------------------");
            System.out.print("|Vui long chon: ");

            luaChon = input.nextInt();

            switch (luaChon) {
                case 1:
                    showAllEmployees();
                    break;
                case 2:
                    showAllDepartments();
                    break;
                case 3:
                    showEmployeesByDepartment();
                    break;
                case 4:
                    addNewEmployee();
                    break;
                case 5:
                    searchEmployee();
                    break;
                case 6:
                    salaryTable();
                    break;
                case 7:
                    sortSalaryUp();
                    break;
                case 8:
                    sortSalaryDown();
                    break;
            }
        } while(luaChon != 9);

    }

    // 1. Hien thi danh sach nhan vien
    public static void showAllEmployees() {
        System.out.println(String.format("%-15s%-30s%-10s%-15s%-25s%-15s%-1s",
                "  ID",
                "  Employee Name",
                "  Age",
                "  Pay Rate",
                "  Start Date",
                "  DeptID",
                "  Number Day Off"));
        for (Staff staff : staffList) {
            staff.displayInformation();
        }

    }
    // 2. Hien thi danh sach cac bo phan trong cong ty
    public static void showAllDepartments() {
        System.out.println(String.format("%-15s%-30s%-10s","  ID Bộ phận","  Tên Bộ phận","  Số nhân viên"));
        for (Department dept : deptList) {
            System.out.println(dept.toString());
        }
    }
    // 3. Hien thi danh sach nhan vien theo tung bo ban
    public static void showEmployeesByDepartment() {
        for (Department dept: deptList) {
            System.out.println(dept.toString());
            for (Staff staff: staffList){
                if (staff.getDeptId().equalsIgnoreCase(dept.getDeptId())){
                    System.out.println(staff.toString());
                }
            }
        }
    }
    //4.Them moi nhan vien
    public static void addNewEmployee() {
        System.out.println("Bạn muốn thêm nhân viên mới hay quản lý mới?");
        System.out.println("Nhập 'E' để thêm nhân viên mới, Nhập 'M' để thêm quản lý mới");
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();

        if (input.equalsIgnoreCase("E")) {
            System.out.println("Nhập mã ID nhân viên: ");
            String id = sc.nextLine();
            System.out.println("Nhập tên nhân viên: ");
            String name = sc.nextLine();
            System.out.println("Nhập tuổi nhân viên: ");
            int age = Integer.parseInt(sc.nextLine());
            System.out.println("Nhập hệ số lương nhân viên: ");
            double payRate = Double.parseDouble(sc.nextLine());
            System.out.println("Nhập ngày vào làm của nhân viên: ");
            String startDate = sc.nextLine();
            System.out.println("Nhập ID bộ phận của nhân viên: ");
            String deptId = sc.nextLine();
            System.out.println("Nhập số ngày nghỉ nhân viên: ");
            int numDayOff = Integer.parseInt(sc.nextLine());
            System.out.println("Nhập lương nhân viên: ");
            float salary = sc.nextFloat();  //bị lỗi khi nhập
            System.out.println("Nhập thời gian làm thêm giờ nhân viên: ");
            double overtimeHour = sc.nextDouble();

            // Thêm nhân viên vào stafflist
            Employee E = new Employee(id, name, age, payRate, startDate, deptId, numDayOff, salary, overtimeHour);
            staffList.add(E);

            for (Department dept : deptList) {
                if (dept.getDeptId().equalsIgnoreCase(deptId)) {
                    dept.setEmployees(dept.getEmployees() + 1);
                }
            }

        } else if (input.equalsIgnoreCase("M")) {
            System.out.println("Nhập mã ID quản lý: ");
            String id = sc.nextLine();
            System.out.println("Nhập tên quản lý: ");
            String name = sc.nextLine();
            System.out.println("Nhập tuổi quản lý: ");
            int age = Integer.parseInt(sc.nextLine());
            System.out.println("Nhập hệ số lương quản lý: ");
            double payRate = Double.parseDouble(sc.nextLine());
            System.out.println("Nhập ngày vào làm của quản lý: ");
            String startDate = sc.nextLine();
            System.out.println("Nhập ID bộ phận của quản lý: ");
            String deptId = sc.nextLine();
            System.out.println("Nhập số ngày nghỉ của quản lý: ");
            int numDayOff = Integer.parseInt(sc.nextLine());
            System.out.println("Nhập lương quản lý: ");

            float salary = sc.nextFloat();
            System.out.println("Nhập chức vụ của quản lý: ");
            sc.nextLine();
            String position = sc.nextLine();

            // Thêm vào stafflist
            Manager M = new Manager(id, name, age, payRate, startDate, deptId, numDayOff, salary, position);
            staffList.add(M);
            for (Department dept : deptList) {
                if (dept.getDeptId().equalsIgnoreCase(deptId)) {
                    dept.setEmployees(dept.getEmployees() + 1);
                }

            }
        }
    }
        // 5. Tìm kiếm thông tin nhân viên theo tên hoặc mã nhân viên
        public static void searchEmployee () {
            System.out.println("Nhập tên nhân viên hoặc ID: ");
            Scanner input = new Scanner(System.in);
            String keyInput = input.nextLine();
            // Tìm kiếm nhân viên
            for (Staff staff : staffList) {
                if (staff.getName().equalsIgnoreCase(keyInput) || staff.getId().equalsIgnoreCase(keyInput)) {
                    if (staff instanceof Employee) {
                        System.out.println(((Employee) staff).toString());
                    } else {
                        System.out.println(((Manager) staff).toString());
                    }
                }
            }
        }
        // 6. Hiển thị bảng lương của nhân viên toàn công ty
        public static void salaryTable () {
            System.out.println(String.format("%-15s%-25s",
                    "  ID",
                    "  Salary"));
            for (Staff staff: staffList) {
                staff.displaySalary();
            }

        }
        // 7. Hiển thị bảng lương của nhân viên theo thứ tự tăng dần
        public static void sortSalaryUp () {
            System.out.println(String.format("%-15s%-25s",
                    "  ID",
                    "  Salary"));

            Collections.sort(staffList, new StaffComparator());


            for (Staff staff : staffList) {
                staff.displaySalary();
            }

        }
        // 8. Hiển thị bảng lương của nhân viên theo thứ tự giảm dần
        public static void sortSalaryDown () {
            System.out.println(String.format("%-15s%-25s",
                    "  ID",
                    "  Salary"));

            Collections.sort(staffList, new StaffComparator2());


            for (Staff staff : staffList) {
                staff.displaySalary();
            }

        }




        //Khởi tạo dư liệu ban đầu

        public static void initData () {
            //Thêm BP
            deptList.add(new Department("d001", "BOM", 1));
            deptList.add(new Department("d002", "Finance", 1));
            deptList.add(new Department("d003", "Engineering", 1));
            deptList.add(new Department("d004", "Sale", 1));
            deptList.add(new Department("d005", "IT", 1));

            //Thêm NV

            staffList.add(new Manager("00001", "Nguyễn Văn A", 30, 5.0, "01/01/2020",
                    "d001", 8, 33000000.0f, "Business Leader"));
            staffList.add(new Manager("00002", "Nguyễn Văn B", 28, 4.8, "01/05/2020",
                    "d002", 8, 29000000.0f, "Project Leader"));
            staffList.add(new Manager("00003", "Nguyễn Văn D", 26, 4.7, "01/09/2020",
                    "d003", 8, 29500000.0f, "Technique Leader"));
            staffList.add(new Employee("00004", "Nguyễn Văn C", 25, 2.5, "01/07/2020",
                    "d004", 8, 7500000.0f, 0));
            staffList.add(new Employee("00005", "Nguyễn Thị F", 26, 2.4, "01/08/2020",
                    "d005", 8, 7200000.0f, 0));

        }


}
