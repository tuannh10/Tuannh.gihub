public interface ICalculator {
    float calculatorSalary();
}

