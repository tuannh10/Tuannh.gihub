public class Department {
   // Thuoc tinh
   private String deptId;
   private String nameDept;
   private int employees;

   // Phuong thuc khoi tao
   public Department() {

   }

   public Department(String deptId, String nameDept, int employees){
      this.deptId = deptId;
      this.nameDept = nameDept;
      this.employees = employees;
   }

   @Override
   public String toString() {
      return  String.format("%-15s%-30s%-10s","|ID: " + deptId,"| Department: " + nameDept ,"| employee: " + employees + "|");
   }

   public String getDeptId(){
      return deptId;
   }
   public void setDeptId(String idDept){
      this.deptId = deptId;
   }
   public  String getNameDept() {
      return  nameDept;
   }
   public void setNameDept(String nameDept){
      this.nameDept = nameDept;
   }

   public int getEmployees(){
      return employees;
   }
   public void setEmployees(int employees){
      this.employees = employees;
   }

}
