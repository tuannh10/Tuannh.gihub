import java.util.Comparator;

public abstract class Staff implements ICalculator{

    private String id;
    private String name;
    private int age;
    private double payRate;
    private String startDate;
    private String deptId;
    private int numDayOff;

    // Phuong thuc khoi tao
    public Staff() {

    }

    public Staff(String id, String name, int age, double payRate, String startDate, String deptId, int numDayOff){
        this.id = id;
        this.name = name;
        this.age = age;
        this.payRate = payRate;
        this.startDate = startDate;
        this.deptId = deptId;
        this.numDayOff = numDayOff;
    }


    // Phuong thuc khac
    public String getId(){                   //id
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getName(){                 //name
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getAge(){                     //Age
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public double getPayRate(){              //payRate
        return payRate;
    }
    public void setPayRate(double payRate) {
        this.payRate = payRate;
    }
    public String getStartDate(){        //startDate
        return startDate;
    }
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    public String getDeptId(){        //Department
        return deptId;
    }
    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }
    public int getNumDayOff(){        //numDayOff
        return numDayOff;
    }
    public void setNumDayOff(int numDayOff) {
        this.numDayOff = numDayOff;
    }

    // Phuong thuc truu tuong
    public abstract void displayInformation();
    public abstract void displaySalary();
    @Override
    public String toString() {
        return String.format("%-15s%-30s%-10s",
                "|ID: " + id,
                "| Employee Name: " + name,
                "| Age: " + age,
                "|");
    }

}



