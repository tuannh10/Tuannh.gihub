import java.util.ArrayList;
import java.util.Scanner;

public class Review {

    public static void main(String[] arg){
        Scanner sc = new Scanner(System.in);
        String Dept = sc.nextLine();

        System.out.println(Dept);
    }


}
