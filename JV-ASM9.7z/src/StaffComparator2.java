import java.util.Comparator;
//Sắp xếp tăng dần
public class StaffComparator2 implements Comparator<Staff> {

    @Override
    public int compare(Staff s1, Staff s2) {
        if (s1.calculatorSalary() == s2.calculatorSalary()) {
            return 0;
        } else if (s1.calculatorSalary() > s2.calculatorSalary()) {
            return -1;
        } else {
            return 1;
        }
    }
}
