import java.text.DecimalFormat;
import java.util.Comparator;

public class Manager extends Staff {
    // Thuoc tinh
    private float salary;
    private String position;

    // Phuong thuc khoi tao
    public Manager() {


    }

    public Manager(String id, String name, int age, double payRate, String startDate, String deptId, int numDayOff, float salary, String position) {
        super(id, name, age, payRate, startDate, deptId, numDayOff);
        this.salary = salary;
        this.position = position;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    @Override
    public void displayInformation() {
        System.out.println(String.format("%-15s%-30s%-10s%-10s%-12s%-15s%-10s%-1s",
                "|ID: " + super.getId(),
                "| Employee Name: " + super.getName(),
                "| Age: " + super.getAge(),
                "| Pay Rate: " + super.getPayRate(),
                "| Start Date: " + super.getStartDate(),
                "| DeptID: " + super.getDeptId(),
                "| Number Day Off: " + super.getNumDayOff(),
                " |"));
    }

    @Override
    public float calculatorSalary() {
        // tinh luong trach nhiem
        float luongTrachNhiem = 0;
        if (position.equalsIgnoreCase("Business Leader")) {
            luongTrachNhiem = 8000000;
        } else if (position.equalsIgnoreCase("Project Leader")) {
            luongTrachNhiem = 5000000;
        } else if (position.equalsIgnoreCase("Technique Leader")) {
            luongTrachNhiem = 6000000;
        }

        // tinh luong
        salary = (float) (getPayRate() * 5000000 + luongTrachNhiem);

        return salary;
    }

    @Override
    public void displaySalary() {
        DecimalFormat df = new DecimalFormat("0.00");
        System.out.println(String.format("|%-15s%-10s|", "ID: " + super.getId(), "Salary: " + df.format(salary)));
    }
}
